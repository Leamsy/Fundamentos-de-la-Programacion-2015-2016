/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2015-2016
// (C) ISMAEL MOYANO ROMERO
// 1�B - GRUPO 3
//
// RELACI�N DE PROBLEMAS 3
// EJERCICIO 18
/*	
   Programa que determina una aproximaci�n al n�mero �ureo seg�n un valor dado.
*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

Diferencia_Aureo(double diferencia){
	
	double aureo;
	double numero_1, numero_2;
	double n;
	double numero_serie;
	double aprox;
	
	
	
	aureo = (1 + sqrt(5)) / 2;
	
	numero_1 = 1;
	numero_2 = 1;
	n = 2;
	
	
	while(abs(aureo - aprox) > diferencia){
		
		numero_serie = numero_1 + numero_2;
		
		
		aprox = (numero_serie + 1) / numero_serie;
		
		
		numero_1 = numero_2;
		numero_2 = numero_serie;
		
		n++;
		
	}
	
return(n);
}



int main()
{

	double n, diferencia;

	
	
	do {
		
		cout << "Introduce la diferencia con el n�mero �ureo: ";
		cin >> diferencia;
	
	} while (diferencia <= 0);
	
	n = Diferencia_Aureo(diferencia);
		
	//Salida de datos
	
	cout << "\nN = " <<n<< "";
	
	
	return(0);
}
