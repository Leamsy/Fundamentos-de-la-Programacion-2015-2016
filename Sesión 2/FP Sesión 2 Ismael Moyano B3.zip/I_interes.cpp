/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2015-2016
// (C) ISMAEL MOYANO ROMERO
// 1�B - GRUPO 3
//
// RELACI�N DE PROBLEMAS 1
// EJERCICIO 2
/*	
   Programa que calcula el inter�s generado tras depositar un determinado capital en un banco durante 1 a�o a plazo fijo.
*/
/***************************************************************************/

#include <iostream>     // Se incluye la librer�a "cmath", necesaria para realizar c�lculos matem�ticos
using namespace std;		// Declara un espacio que contiene un conjunto de objetos relacionados

int main()
{
	// Definici�n de datos y variables
	
	double capital; 	 		// Capital inicial
	double interes;			// Inter�s generado por el capital depositado
	double total;    			// Capital al cabo de 1 a�o
	
	// Entrada de datos
	
	cout << "\nIntroduzca el capital:";
	cin >> capital;
	cout << "\nIntroduzca el % de inter�s:";
	cin >> interes;

	//Operaciones

	total = capital + capital * interes / 100 ;


	// Salida de datos

	cout << "\n\nAl cabo de un a�o se tendr�n " << total << " �.";

	return(0);
}
